/**
 * 01 - Getting Started
 * Declare a variable, perform some math, output the result
 */

var initialNumber = 0;
var finalNumber = initialNumber + 10;

console.log(finalNumber);